﻿using System.Windows;

namespace Oblsuga
{
    /// <summary>
    /// Logika interakcji dla klasy App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
